
import numpy as np
import sys
import copy
import time
import random
import argparse
######################################################

class epsGreedyAgent: 
    def __init__(self):
        self.name = "Eric the Epsilon Greedy Agent"
    
    def recommendArm(self, bandit, history):
        #Hey, your code goes here!
        return False
