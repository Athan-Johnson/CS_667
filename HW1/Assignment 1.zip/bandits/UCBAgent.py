
import numpy as np
import sys
import copy
import time
import random
import argparse

class UCBAgent:
    def __init__(self):
        self.name = "Uma the UCB Agent"
    
    def recommendArm(self, bandit, history):
        #Hey, your code goes here!
        return False
